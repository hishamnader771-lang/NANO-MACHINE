package com.nanomachine.app

import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.animation.ValueAnimator
import android.widget.*
import org.json.JSONArray

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("nano_data", Context.MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private var xp = 0
    private var coins = 0
    private var completed = 0
    private val tasks = mutableListOf<String>()
    private val done = mutableSetOf<Int>()
    private val bg = Color.rgb(5, 11, 24)
    private val cyan = Color.rgb(0, 229, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        loadData()
        showHome()
    }

    private fun loadData() {
        xp = prefs.getInt("xp", 0)
        coins = prefs.getInt("coins", 0)
        completed = prefs.getInt("completed", 0)
        val rawTasks = prefs.getString("tasks", null)
        if (rawTasks == null) {
            tasks.addAll(listOf(
                "مراجعة أهداف اليوم",
                "جلسة تعلم لمدة 25 دقيقة",
                "نشاط بدني مناسب مع وقت للراحة",
                "قراءة أو تعلم شيء جديد",
                "ترتيب المهام والاستعداد للغد"
            ))
        } else {
            val arr = JSONArray(rawTasks)
            for (i in 0 until arr.length()) tasks.add(arr.getString(i))
        }
        prefs.getString("done", "")?.takeIf { it.isNotBlank() }?.split(",")?.forEach {
            it.toIntOrNull()?.let(done::add)
        }
    }

    private fun saveData() {
        val arr = JSONArray()
        tasks.forEach(arr::put)
        prefs.edit()
            .putInt("xp", xp)
            .putInt("coins", coins)
            .putInt("completed", completed)
            .putString("tasks", arr.toString())
            .putString("done", done.joinToString(","))
            .apply()
    }

    private fun rank() = when {
        xp >= 10000 -> "S"
        xp >= 6000 -> "A"
        xp >= 3000 -> "B"
        xp >= 1500 -> "C"
        xp >= 500 -> "D"
        else -> "E"
    }
    private fun level() = xp / 100 + 1

    private fun makeLayout(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            setBackgroundColor(bg)
        }
        val header = TextView(this).apply {
            text = "NANO MACHINE  /  $title"
            textSize = 20f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 18)
        }
        root.addView(header)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun label(value: String, size: Float = 17f, color: Int = Color.WHITE) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            setPadding(8, 10, 8, 10)
        }

    private fun actionButton(value: String, action: () -> Unit) =
        Button(this).apply {
            text = value
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(15, 55, 78))
            setOnClickListener { action() }
        }

    private fun showHome() {
        makeLayout("SYSTEM")
        root.addView(EnergyCore(this), LinearLayout.LayoutParams(190, 190).apply {
            gravity = Gravity.CENTER
        })
        root.addView(label("مرحباً، تم تشغيل النظام", 22f, cyan).apply {
            gravity = Gravity.CENTER
        })
        root.addView(label("الرتبة: ${rank()}     المستوى: ${level()}").apply {
            gravity = Gravity.CENTER
        })
        root.addView(label("XP: $xp     العملات الافتراضية: $coins").apply {
            gravity = Gravity.CENTER
        })
        val progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = xp % 100
            progressTintList = android.content.res.ColorStateList.valueOf(cyan)
        }
        root.addView(progress)
        root.addView(actionButton("المهام اليومية") { showTasks() })
        root.addView(actionButton("الإحصائيات والرتبة") { showStats() })
        root.addView(actionButton("NANO AI") { showAI() })
        root.addView(actionButton("الإعدادات") { showSettings() })
    }

    private fun showTasks() {
        makeLayout("DAILY TASKS")
        root.addView(label("أكمل المهام المناسبة لك لتحصل على نقاط خبرة", 17f, cyan))
        tasks.forEachIndexed { index, task ->
            val check = CheckBox(this).apply {
                text = task
                textSize = 16f
                setTextColor(Color.WHITE)
                buttonTintList = android.content.res.ColorStateList.valueOf(cyan)
                isChecked = done.contains(index)
            }
            check.setOnCheckedChangeListener { _, checked ->
                val changed = if (checked) done.add(index) else done.remove(index)
                if (changed) {
                    if (checked) {
                        xp += 25
                        coins += 5
                        completed++
                    } else {
                        xp = (xp - 25).coerceAtLeast(0)
                        coins = (coins - 5).coerceAtLeast(0)
                        completed = (completed - 1).coerceAtLeast(0)
                    }
                    saveData()
                    showTasks()
                }
            }
            root.addView(check)
        }
        val input = EditText(this).apply {
            hint = "اكتب مهمة جديدة"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
        }
        root.addView(input)
        root.addView(actionButton("إضافة مهمة") {
            val value = input.text.toString().trim()
            if (value.isNotEmpty()) {
                tasks.add(value)
                saveData()
                showTasks()
            }
        })
        root.addView(actionButton("العودة للرئيسية") { showHome() })
    }

    private fun showStats() {
        makeLayout("PLAYER STATUS")
        root.addView(label("ملف النظام", 22f, cyan))
        root.addView(label("الرتبة الحالية: ${rank()}"))
        root.addView(label("المستوى: ${level()}"))
        root.addView(label("نقاط الخبرة: $xp"))
        root.addView(label("العملات الافتراضية: $coins"))
        root.addView(label("إجمالي الإنجازات: $completed"))
        root.addView(label("الرتب: E → D → C → B → A → S", 18f, cyan))
        root.addView(actionButton("العودة للرئيسية") { showHome() })
    }

    private fun showAI() {
        makeLayout("NANO AI")
        root.addView(label("أنا NANO AI، المساعد المحلي الأساسي.", 18f, cyan))
        val conversation = label("النظام جاهز لاستقبال رسالتك.")
        root.addView(conversation)
        val input = EditText(this).apply {
            hint = "اكتب رسالتك..."
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
        }
        root.addView(input)
        root.addView(actionButton("إرسال") {
            val message = input.text.toString().trim()
            if (message.isNotEmpty()) {
                conversation.text = "أنت: $message\n\nNANO AI: ${localReply(message)}"
                input.text.clear()
            }
        })
        root.addView(actionButton("العودة للرئيسية") { showHome() })
    }

    private fun localReply(message: String): String {
        val m = message.lowercase()
        return when {
            m.contains("مرحبا") || m.contains("السلام") -> "أهلاً بك. النظام يعمل."
            m.contains("مستوى") || m.contains("رتبة") -> "مستواك ${level()} ورتبتك ${rank()}."
            m.contains("مهام") -> "لديك ${tasks.size - done.size} مهام غير مكتملة."
            m.contains("خبرة") || m.contains("xp") -> "رصيد الخبرة الحالي $xp."
            m.contains("مساعدة") -> "يمكنني عرض مستواك ومهامك وإحصائياتك الأساسية."
            else -> "هذه نسخة محلية أولية وليست نموذج ذكاء اصطناعي لغوي كامل."
        }
    }

    private fun showSettings() {
        makeLayout("SETTINGS")
        root.addView(label("إعدادات النظام", 22f, cyan))
        root.addView(label("البيانات محفوظة محلياً على الجهاز."))
        root.addView(label("هذه النسخة لا تستخدم الميكروفون أو خدمات سحابية."))
        root.addView(actionButton("إعادة ضبط بيانات النظام") {
            prefs.edit().clear().apply()
            xp = 0; coins = 0; completed = 0
            done.clear()
            tasks.clear()
            tasks.addAll(listOf(
                "مراجعة أهداف اليوم",
                "جلسة تعلم لمدة 25 دقيقة",
                "نشاط بدني مناسب مع وقت للراحة",
                "قراءة أو تعلم شيء جديد",
                "ترتيب المهام والاستعداد للغد"
            ))
            saveData()
            showHome()
        })
        root.addView(actionButton("العودة للرئيسية") { showHome() })
    }

    override fun onDestroy() {
        saveData()
        super.onDestroy()
    }
}

private class EnergyCore(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var angle = 0f
    private val cyan = Color.rgb(0, 229, 255)
    private val animator = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 6000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            angle = it.animatedValue as Float
            invalidate()
        }
    }

    init { animator.start() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = width.coerceAtMost(height) * 0.28f

        paint.style = Paint.Style.FILL
        paint.color = Color.argb(35, 0, 229, 255)
        canvas.drawCircle(cx, cy, radius * 1.8f, paint)

        paint.shader = android.graphics.RadialGradient(
            cx, cy, radius,
            intArrayOf(Color.WHITE, cyan, Color.rgb(0, 55, 110), Color.TRANSPARENT),
            floatArrayOf(0f, 0.35f, 0.75f, 1f),
            android.graphics.Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, radius, paint)
        paint.shader = null

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.color = cyan
        canvas.save()
        canvas.rotate(angle, cx, cy)
        canvas.drawOval(cx - radius * 1.5f, cy - radius * 0.55f,
            cx + radius * 1.5f, cy + radius * 0.55f, paint)
        canvas.restore()

        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        canvas.drawCircle(cx, cy, radius * 0.12f, paint)
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }
}
